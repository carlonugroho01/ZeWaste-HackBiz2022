# WebsiteZeWaste

## English

This Website is created for Ze-Waste. Ze-Waste is the first ever e-waste recycle company of the Indonesian mobile telecommunications industry. We value your unused mobile phones, batteries, accessories and distribute it to our NGO partners around Indonesia.

This Repository has **MIT License.**   
This license allows the user to make any changes to the program code. This license only requires the user to include the license and author's copyright in the redistributed code and there is no prohibition against using the trademark of the original author. In addition, the user also has no right to sue the manufacturer when there is damage to the software.

## Bahasa

Website ini dibuat untuk Ze-Waste. Ze-Waste adalah perusahaan daur ulang limbah elektronik pertama dari industri telekomunikasi seluler Indonesia. Kami menghargai ponsel, baterai, aksesori Anda yang tidak terpakai dan mendistribusikannya ke mitra LSM kami di seluruh Indonesia.

Repository ini memiliki **Lisensi MIT.**      
Lisensi ini membolehkan pengguna untuk melakukan perubahan apapun pada kode program. Lisensi ini hanya mewajibkan pengguna untuk menyertakan lisensi dan copyright pembuat pada kode yang didistribusikan ulang dan tidak ada larangan untuk menggunakan trademark dari pembuat asli. Selain itu pengguna juga tidak berhak untuk menuntut pembuat ketika terjadi kerusakan pada perangkat lunak tersebut.

